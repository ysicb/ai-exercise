import logging
from typing import List, Union

import numpy as np
from PIL import Image
from doctr.models import fast_base
from doctr.models import parseq

from yocr.OCRConfig import OCRConfig
from yocr.OCRBase import OCRBase
from yocr.data_struct.Detection import Detection
from yocr.data_struct.OcrResult import OcrResult
from yocr.data_struct.Recognition import Recognition
from yocr.doctr.DoctrOCRConfig import DoctrOCRConfig
from yocr.utils.InferenceUtils import InferenceUtils
import ssl

ssl._create_default_https_context = ssl._create_unverified_context

logger = logging.getLogger(__name__)


class DoctrOCR(OCRBase):
    def __init__(self, config: OCRConfig) -> None:
        super().__init__(config)
        from doctr.models import ocr_predictor
        import torch

        engine_config = DoctrOCRConfig()
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.text_detector = fast_base(pretrained=True)
        self.text_recognizer = parseq(pretrained=True)
        self.doctrModel = ocr_predictor(
            det_arch=engine_config.det_arch,
            reco_arch=engine_config.reco_arch,
            preserve_aspect_ratio=False,
            pretrained=True,
        )

    def run(self, image: Union[str, Image.Image], **kwargs) -> List[OcrResult]:
        from doctr.io import DocumentFile, tensor_from_pil

        logger.info("run doctr")
        if type(image) is str:
            if image.endswith(".pdf"):
                doc = DocumentFile.from_pdf(image)
            elif (
                image.endswith(".jpg")
                or image.endswith(".png")
                or image.endswith(".jpeg")
                or image.endswith(".tif")
            ):
                doc = DocumentFile.from_images(image)
            else:
                raise Exception("image must be a string path to a pdf or image")
            result = self.doctrModel(doc)
            return self.convert_to_OcrResult(result)
        elif isinstance(image, Image.Image):
            doc = tensor_from_pil(image.convert("RGB"))
            result = self.doctrModel([doc])
            return self.convert_to_OcrResult(result)
        else:
            raise Exception("image must be a string path or a PIL Image")

    def run_detection(
        self, image: Union[str, Image.Image], **kwargs
    ) -> List[Detection]:
        logger.info("run doctr detection")
        if not InferenceUtils.is_image(image):
            image = Image.open(image).convert("RGB")

        polygon_outs = self.text_detector([np.asarray(image)])
        detection_image = []
        for item in polygon_outs[0]:
            if type(item) is dict:
                item = item["words"]
            detection_image.append(
                Detection().set_coordinates_from_bbox(
                    Detection.convert_polygon_to_xyxy(item.ravel())
                )
            )
        return detection_image

    def run_recognition(
        self, image, detections: [Detection], **kwargs
    ) -> List[OcrResult]:
        logger.info("run doctr recognition")
        if not InferenceUtils.is_image(image):
            image = Image.open(image)
        width = image.width
        height = image.height
        detection: Detection
        ocrResults: List[OcrResult] = []
        from tqdm import tqdm

        for detection in tqdm(detections):
            # crop image for that particular detection
            xyxy = detection.get_coordinates_in_bbox()
            try:
                xyxy = Detection.unormalize_xyxy(xyxy, height, width)
                cropped_image = image.crop(xyxy)
                words_confidences = self.text_recognizer([np.asarray(cropped_image)])
            except Exception as e:
                print(e)
                words_confidences = [("ERROR", 0.0)]
            # print(words_confidences)
            # merge all texts:
            text = str(words_confidences[0][0])
            confidence = float(words_confidences[0][1])
            ocrResults.append(
                OcrResult(
                    detection=detection,
                    recognition=Recognition(text=text, conf_score=confidence),
                )
            )
        return ocrResults

    def convert_to_OcrResult(self, result) -> List[OcrResult]:
        ocrResults = []
        result = result.export()
        for block_num, block in enumerate(result["pages"][0]["blocks"]):
            for line_n, line in enumerate(block["lines"]):
                for word in line["words"]:
                    detection = Detection(
                        conf_score=round(word["confidence"], 2),
                    ).set_coordinates_from_geometry(word["geometry"])
                    recognition = Recognition(
                        text=word["value"], conf_score=word["confidence"]
                    )
                    # doctr does not return word-based orientation
                    ocrResults.append(
                        OcrResult(detection=detection, recognition=recognition)
                    )
        return ocrResults
