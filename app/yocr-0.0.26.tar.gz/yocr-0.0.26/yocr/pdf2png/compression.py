import io
import zipfile
from zipfile import ZipFile

from PIL import Image


def zip_images(images):
    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, "w") as zip_file:
        for idx, img in enumerate(images):
            img_bytes = io.BytesIO()
            img.save(img_bytes, format="PNG")
            img_name = f"image_{idx + 1}.png"
            zip_file.writestr(img_name, img_bytes.getvalue())
    return zip_buffer


def unzip_content_to_images(content) -> list[Image.Image]:
    images = []
    with ZipFile(io.BytesIO(content), "r") as zip_file:
        for filename in zip_file.namelist():
            with zip_file.open(filename) as image_file:
                # Load image using PIL (Pillow)
                img = Image.open(image_file)
                images.append(img)
    return images
