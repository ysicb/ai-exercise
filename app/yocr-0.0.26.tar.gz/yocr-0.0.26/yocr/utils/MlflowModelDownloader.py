import logging
import os
import shutil
import mlflow

logging = logging.getLogger(__name__)


class MlflowModelDownloader:
    def __init__(self, mlflow_tracking_uri="https://mlflow-external.yardi-qa.com"):
        mlflow_tracking_uri = mlflow_tracking_uri

        mlflow.set_tracking_uri(mlflow_tracking_uri)

    def download_model(self, mlflow_run_id, dir_to_save):
        """
        :param mlflow_run_id: mlflow run id
        :param dir_to_save: directory to save the model
        :return: mlflow model
        You can use extract_model_from_pyfunc(mlflow_model).model to get the model
        """
        if not os.path.exists(dir_to_save):
            os.makedirs(dir_to_save)
        else:
            logging.warning(f"Directory {dir_to_save} already exists!")
            # remove the directory and create a new one
            shutil.rmtree(dir_to_save)
            os.makedirs(dir_to_save)
            logging.warning(f"Recreated directory {dir_to_save} after removing inside!")

        mlflow_model = mlflow.pyfunc.load_model(
            f"runs:/{mlflow_run_id}/model", dst_path=dir_to_save
        )
        return mlflow_model
