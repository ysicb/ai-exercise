from PIL import Image


class InferenceUtils:
    def __init__(self) -> None:
        super().__init__()

    @staticmethod
    def is_image(image):
        return isinstance(image, Image.Image)
