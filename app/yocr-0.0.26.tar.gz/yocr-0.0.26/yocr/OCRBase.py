import time
from abc import ABC, abstractmethod
from typing import List, Union

import numpy as np
from PIL import Image
from collections import defaultdict

from yocr.OCRConfig import InferenceType
from yocr.data_struct.Detection import Detection
from yocr.data_struct.Line import Line
from yocr.data_struct.OcrResult import OcrResult
from yocr.data_struct.Recognition import Recognition
from yocr.utils.PatchUtils import (
    patch_image,
    get_detections_for_full_size_from_detection,
)
from yocr.utils.InferenceUtils import InferenceUtils

from yocr.data_struct.Block import Block
from yocr.utils.VisualizationUtils import VisualizationUtils


class OCRBase(ABC):
    def __init__(self, config) -> None:
        super().__init__()
        self.config = config
        print("OCRBase config: ", self.config.__dict__)

    def update_config(self, config):
        self.config = config

    @abstractmethod
    def run(self, image: Union[str, Image.Image], **kwargs) -> List[OcrResult]:
        raise NotImplementedError("Please implement this method")

    @abstractmethod
    def run_detection(
        self, image: Union[str, Image.Image], **kwargs
    ) -> List[Detection]:
        """
        Run text detection on the image
        :param image: image path or PIL image
        """
        raise NotImplementedError("Please implement this method")

    @abstractmethod
    def run_recognition(
        self, image: Union[str, Image.Image], detections: list[Detection], **kwargs
    ) -> List[OcrResult]:
        """
        Run text recognition on the image
        :param image: image path or PIL image
        """
        raise NotImplementedError("Please implement this method")

    @staticmethod
    def get_hierarchy_of_info_from_lines(
        word_results: list[OcrResult], image_width, image_height
    ) -> list[Block]:
        """
        Get the hierarchy of information from the word level results
        :param word_results: word level results
        :param image_width: width of the image
        :param image_height: height of the image
        :return: list of blocks
        """
        blocks, _ = Block.get_blocks_from_line_level(
            word_results, image_width, image_height
        )
        return blocks

    @staticmethod
    def get_hierarchy_of_info_from_words(
        word_results: list[OcrResult], image_width, image_height
    ) -> list[Block]:
        """
        Get the hierarchy of information from the word level results
        :param word_results: word level results
        :param image_width: width of the image
        :param image_height: height of the image
        :return: list of blocks
        """
        blocks = Block.get_blocks_from_word_level(
            word_results, image_width, image_height
        )
        return blocks

    def get_words_from_line_level(
        self, word_results: list[OcrResult], image_width, image_height
    ) -> list[OcrResult]:
        _, words = Block.get_blocks_from_line_level(
            word_results, image_width, image_height
        )

        return words

    def get_lines_from_word_level(
        self, word_results: list[OcrResult], image_width, image_height
    ) -> list[OcrResult]:
        blocks = self.get_hierarchy_of_info_from_words(
            word_results, image_width, image_height
        )
        lines = []
        for block in blocks:
            line: Line
            for line in block.lines:
                text = line.get_text()
                det_conf, rec_conf = line.get_median_confidence()
                ocrRes = OcrResult(
                    detection=Detection(
                        coordinates=line.coordinates, conf_score=det_conf
                    ),
                    recognition=Recognition(text=text, conf_score=rec_conf),
                    direction=line.get_line_direction(),
                )
                lines.append(ocrRes)

        return lines

    def visualize_hierarchy(
        self,
        image: Union[str, Image.Image],
        words: list[OcrResult],
        draw_block=True,
        draw_line=True,
        draw_word=True,
        display=True,
        out_path=None,
    ):
        if not InferenceUtils.is_image(image):
            image = Image.open(image)

        blocks = self.get_hierarchy_of_info_from_words(words, image.width, image.height)
        image = VisualizationUtils.generate_block_line_word_bbox_overlay(
            image, blocks, draw_block, draw_line, draw_word
        )
        if out_path is not None:
            image.save(out_path)
        if display:
            from matplotlib import pyplot as plt

            plt.imshow(image)

    @staticmethod
    def visualize_detection_results(
        image: Union[str, Image.Image],
        ocrResults: list[OcrResult],
        out_path=None,
        display=True,
    ):
        if not InferenceUtils.is_image(image):
            file_name = image
            image = Image.open(file_name)
        image = np.asarray(image)
        # convert detection to xyxy
        detections = [ocrResult.detection for ocrResult in ocrResults]
        xyxyBoxes = Detection.convert_detection_list_to_xyxy(detections)
        return VisualizationUtils.generate_xyxy_overlay(
            image, xyxyBoxes, out_filepath=out_path, display=display
        )

    @staticmethod
    def visualize_ocr_results(
        image: Union[str, Image.Image],
        ocrResults: list[OcrResult],
        out_path=None,
        display=True,
    ):
        if not InferenceUtils.is_image(image):
            file_name = image
            image = Image.open(file_name)
        width, height = image.size[0], image.size[1]
        image = np.asarray(image)
        # convert detection to xyxy
        detections = [ocrResult.detection for ocrResult in ocrResults]
        xyxyBoxes = Detection.convert_detection_list_to_xyxy(detections)
        pds = VisualizationUtils.create_box_records(ocrResults, height, width)
        rect_color = (0, 0, 255)  # blue
        thickness = 1
        text_color = (0, 0, 0)  # green
        for pd in pds:
            image = VisualizationUtils._draw_recognition_text_box(
                image, pd, pd["text"], rect_color, text_color, thickness
            )
        return image

    @staticmethod
    def save_ocr_groundtruth_and_prediction_visualization(
        gt_ocr_results: List[OcrResult],
        pd_ocr_results: List[OcrResult],
        image_path: str,
        text_comparator=None,
        outpath: str = "./gt_viz.png",
        thresh: float = 0.5,
        display: bool = False,
        extra_info: str = None,
        display_gt_image: bool = True,
    ):
        from matplotlib import pyplot as plt
        import cv2

        def iou():
            return (
                lambda poly_1, poly_2: poly_1.intersection(poly_2).area
                / poly_1.union(poly_2).area
            )

        get_iou = iou()

        if text_comparator is None:

            def eq():
                return lambda x, y: x == y

            text_comparator = eq()

        thickness = 1
        gt_color = (0, 255, 0)  # green
        fn_color = (255, 0, 0)  # red
        pd_color = (0, 0, 255)  # blue
        eq_text_color = (0, 0, 0)
        inc_text_color = (255, 0, 0)

        image = Image.open(image_path)
        width, height = image.size[0], image.size[1]
        gt_image = np.asarray(image)
        pd_image = gt_image.copy()

        gts = VisualizationUtils.create_box_records(gt_ocr_results, height, width)
        preds = VisualizationUtils.create_box_records(pd_ocr_results, height, width)

        # find intersections between gt and pd
        # linked list, id is gt idx, list contains pd idx's
        intersections = defaultdict(lambda: [])
        for gt in gts:
            for pd in preds:
                if gt["poly"].intersects(pd["poly"]):
                    intersections[gt["idx"]].append(pd["idx"])
        if display_gt_image:
            for gt_idx, gt in enumerate(gts):
                cv2.rectangle(
                    gt_image, gt["coords"][0], gt["coords"][2], gt_color, thickness
                )
        all_text_lines = []
        vertical_text_lines = []
        drawn_preds = set()
        for gt in gts:
            pds = intersections[gt["idx"]]
            # plot all prediction boxes with non-zero
            # intersection with groundtruth boxes
            for pd_idx in pds:
                pd = preds[pd_idx]
                iou = get_iou(gt["poly"], pd["poly"])
                if iou > thresh:
                    rect_color = pd_color
                else:
                    rect_color = fn_color
                    # if the threshold isn't met, add red box to gt image to show fn
                    if display_gt_image:
                        cv2.rectangle(
                            gt_image,
                            gt["coords"][0],
                            gt["coords"][2],
                            fn_color,
                            thickness,
                        )
                # draw box on pd image with text color based on text equality
                text_color = (
                    eq_text_color
                    if text_comparator(gt["text"], pd["text"])
                    else inc_text_color
                )
                if pd["angle"] == 0:
                    pd_image = VisualizationUtils._draw_recognition_text_box(
                        pd_image, pd, pd["text"], rect_color, text_color, thickness
                    )
                else:
                    pd_image = VisualizationUtils._draw_recognition_text_box(
                        pd_image,
                        pd,
                        str(pd["idx"]),
                        rect_color,
                        text_color,
                        thickness,
                        text_size=20,
                    )
                    vertical_text_lines.append(
                        {
                            "gt": gt["idx"],
                            "pd": pd["idx"],
                            "gt_text": gt["text"],
                            "pd_text": pd["text"],
                            "iou": iou,
                        }
                    )
                all_text_lines.append(
                    {
                        "gt": gt["idx"],
                        "pd": pd["idx"],
                        "gt_text": gt["text"],
                        "pd_text": pd["text"],
                        "iou": iou,
                    }
                )
                drawn_preds.add(pd["idx"])

        # plot all predictions boxes that haven't been plotted yet
        # set where exists pd boxes s.t. each has no intersection with gt boxes
        undrawn_preds = set([pred["idx"] for pred in preds]) - drawn_preds
        undrawn_preds = [preds[i] for i in undrawn_preds]
        print(
            f"found {len(drawn_preds)} preds with non-zero gt iou."
            f"\nfound {len(undrawn_preds)} preds with no gt overlap"
        )
        for pd in undrawn_preds:
            # plot pd as red box in pd_image
            pd_image = VisualizationUtils._draw_recognition_text_box(
                pd_image, pd, pd["text"], fn_color, fn_color, thickness
            )
            all_text_lines.append(
                {
                    "gt": None,
                    "pd": pd["idx"],
                    "gt_text": None,
                    "pd_text": pd["text"],
                    "iou": 0,
                }
            )
            if pd["angle"] != 0:
                vertical_text_lines.append(
                    {
                        "gt": None,
                        "pd": pd["idx"],
                        "gt_text": None,
                        "pd_text": pd["text"],
                        "iou": 0,
                    }
                )

        if display_gt_image:
            if height > width:
                fig, axs = plt.subplots(1, 2, figsize=(50, 150))
            else:
                fig, axs = plt.subplots(2, 1, figsize=(150, 50))

            axs[0].imshow(gt_image)
            axs[0].set_title(f"groundtruth: {extra_info}")
            axs[1].imshow(pd_image)
            axs[1].set_title("prediction:")
            plt.tight_layout()
            print(f"saving figure to {outpath}")
            plt.savefig(outpath, bbox_inches="tight")

        else:
            fig, ax = plt.subplots(1, 1, figsize=(50, 75))
            ax.imshow(pd_image)
            ax.set_title("prediction:")
            plt.tight_layout()
            print(f"saving figure to {outpath}")
            plt.savefig(outpath, bbox_inches="tight")

        if display:
            plt.show()
        plt.close()

        all_text_line_path = f"{outpath.split('.')[0]}_all.txt"
        vertical_text_line_path = f"{outpath.split('.')[0]}_vertical.txt"
        print(
            f"saving text_lines to: {all_text_line_path} and {vertical_text_line_path}"
        )

        header = ["gt", "pd", "pd_text", "gt_text", "iou"]
        with open(all_text_line_path, "w") as f:
            f.write(",".join(header))
            f.writelines(
                list(
                    map(
                        lambda t: ",".join([str(t[key]) for key in header]),
                        all_text_lines,
                    )
                )
            )
        with open(vertical_text_line_path, "w") as f:
            f.write(",".join(header))
            f.writelines(
                list(
                    map(
                        lambda t: ",".join([str(t[key]) for key in header]),
                        vertical_text_lines,
                    )
                )
            )

    def run_with_whiteout(
        self,
        image: Union[str, Image.Image],
        detections: [Detection],
        rect_images: [np.ndarray] = None,
        white_detection: bool = False,
        order="none",
        clean=False,
    ) -> list[OcrResult]:
        """
        White parts of image out of detection boxes then call ocr on whiteout image
        """
        if isinstance(image, str):
            image = Image.open(image)
        if white_detection:
            image = self.white_detections(image, detections)
        else:
            image = self.white_except_detections(
                image, detections, rect_images=rect_images
            )
        return self.__call__(image, order, clean)

    @staticmethod
    def white_detections(image, detections) -> Image.Image:
        """
        white-out the detection boxes
        """
        image = np.array(image)
        height, width, _ = image.shape
        for index, detection in enumerate(detections):
            xyxy = detection.get_coordinates_in_bbox_unnormalized(height, width)
            xmin, ymin, xmax, ymax = xyxy
            xmin = int(xmin)
            ymin = int(ymin)
            xmax = int(xmax)
            ymax = int(ymax)
            # white pixels detected already
            image[ymin:ymax, xmin:xmax, :] = 255
        image = Image.fromarray(image)
        return image

    @staticmethod
    def white_except_detections(
        image, detections, rect_images: [np.ndarray] = None
    ) -> Image.Image:
        if rect_images is None:
            rect_images = [None] * len(detections)

        image = np.array(image)
        height, width, _ = image.shape
        # create same size image with all white pixels
        whiteout_image = np.ones(image.shape, dtype=np.uint8) * 255
        for index, detection in enumerate(detections):
            xyxy = detection.get_coordinates_in_bbox_unnormalized(height, width)
            xmin, ymin, xmax, ymax = xyxy
            xmin = int(xmin)
            ymin = int(ymin)
            xmax = int(xmax)
            ymax = int(ymax)
            # copy those pixels in image to whiteout_image
            if rect_images[index] is not None and not rect_images[index].any():
                whiteout_image[ymin:ymax, xmin:xmax, :] = rect_images[index][
                    ymin:ymax, xmin:xmax, :
                ]
            else:
                whiteout_image[ymin:ymax, xmin:xmax, :] = image[ymin:ymax, xmin:xmax, :]
        image = Image.fromarray(whiteout_image)
        return image

    def __call__(
        self, image: Union[str, Image.Image], order="none", clean=False
    ) -> list[OcrResult]:
        """
        Run text detection and recognition on the image by handling tile-based approach
        :param image: image path or PIL image
        :param order: order of the words in the image:
            - info_box: order by info box
            - l2r_t2b: left to right, top to bottom
            - line: line by line
            - reverse reversed
            - none: no order
        :return: list of OcrResult
        """
        if not InferenceUtils.is_image(image):
            image = Image.open(image)
        else:
            image = image

        if self.config.INFERENCE_TYPE is InferenceType.FULL:
            ocrResults = self.run(image)
        else:
            output_detection = self.run_detection_patch(
                image,
                self.config.TILE_ROW_COUNT,
                self.config.TILE_COL_COUNT,
                self.config.TILE_OVERLAP,
            )
            ocrResults = self.run_recognition(image, output_detection)

        ocrResults = self.apply_order(
            ocrResults, image, order, width=image.width, height=image.height
        )

        if clean:
            ocrResults = self.clean(ocrResults)
        return ocrResults

    def apply_order(self, ocrResults, image, order, width, height):
        from yocr.OcrResultsOrder import OcrResultsOrder

        if order == "info_box":
            ocrResults = OcrResultsOrder.order_info_box(ocrResults, image)
        if order == "l2r_t2b":
            ocrResults = OcrResultsOrder.order_from_l2r_t2b(ocrResults)
        elif order == "line":
            ocrResults = OcrResultsOrder.order_words(ocrResults, width, height)
        elif order == "reverse":
            ocrResults = ocrResults[::-1]
        return ocrResults

    def clean(self, ocrResults: list[OcrResult]):
        ocrResults_clean = []
        for ocrResult in ocrResults:
            ocrResult.recognition.text = ocrResult.recognition.text.replace(" - ", "-")
            ocrResult.recognition.text = ocrResult.recognition.text.replace("- ", "-")
            ocrResult.recognition.text = ocrResult.recognition.text.replace(" -", "-")
            if ocrResult.recognition.text != "":
                ocrResults_clean.append(ocrResult)

        return ocrResults_clean

    def run_detection_patch(
        self, image: Union[str, Image.Image], row_patch, col_patch, overlap=0
    ):
        if not InferenceUtils.is_image(image):
            file_name = image
            image = Image.open(file_name)
        image = np.asarray(image)
        patches, patch_bboxes = patch_image(image, row_patch, col_patch, overlap)
        width = image.shape[1]
        height = image.shape[0]
        results = []
        for image_p, patch_bbox in zip(patches, patch_bboxes):
            image_p = Image.fromarray(image_p.astype("uint8"))
            results.append(self.run_detection(image_p))
        reconstruct_output = get_detections_for_full_size_from_detection(
            results, patch_bboxes, width, height
        )
        return reconstruct_output

    def evaluate_text_detection(
        self,
        images: Union[List[str], List[Image.Image]],
        target_detections: list[list[Detection]],
        iou_thresh=0.5,
        row_col_patch=(None, None),
        overlap=0,
    ):
        from doctr.utils import LocalizationConfusion

        row, col = row_col_patch
        metric = LocalizationConfusion(iou_thresh=iou_thresh)
        metric_per_image = LocalizationConfusion(iou_thresh=iou_thresh)
        index_precision_recall_iou = []
        times = []
        for file_index, image in enumerate(images):
            if InferenceUtils.is_image(image):
                print("Processing file: ", file_index)
                file_name = file_index
            else:
                file_name = image
                print("Processing file: ", file_name)
                image = Image.open(file_name)
                file_name = file_name.split("/")[-1]
            st = time.process_time()
            if col is not None and row is not None:
                results: list[Detection] = self.run_detection_patch(
                    image, row, col, overlap=overlap
                )
            else:
                results: list[Detection] = self.run_detection(image)
            et = time.process_time()
            xyxys_out = Detection.convert_detection_list_to_xyxy(
                results,
                unormalize=True,
                width=image.size[0],
                height=image.size[1],
            )

            target_detection_page: list[Detection] = target_detections[file_index]
            xyxys_target = Detection.convert_detection_list_to_xyxy(
                target_detection_page,
                unormalize=True,
                width=image.size[0],
                height=image.size[1],
            )
            try:
                xyxys_target = np.asarray(xyxys_target)
                print("target size:", xyxys_target.shape)
                xyxys_out = np.asarray(xyxys_out)
                print("output size", xyxys_out.shape)
                metric.update(xyxys_target, xyxys_out)
                metric_per_image.update(xyxys_target, xyxys_out)
                recall, precision, miou = metric_per_image.summary()
                index_precision_recall_iou.append((file_name, precision, recall, miou))
                metric_per_image.reset()
            except Exception as e:
                print(e)
                print(file_index)
            times.append(et - st)

        print(
            "{:<8} {:<15} {:<10} {:<10}".format("index", "precision", "recall", "iou")
        )
        for index, precision, recall, miou in index_precision_recall_iou:
            print("{:<8} {:<15} {:<10} {:<10}".format(index, precision, recall, miou))

        print("Average time: ", np.mean(times))
        print(
            f"Average time: {np.mean(times)}"
            f" -- Min time: {np.min(times)}"
            f" -- Max time: {np.max(times)}"
        )

        print("recall", "precision", "meanIOU")
        recall, precision, miou = metric.summary()
        f1 = 0
        try:
            f1 = 2 * (precision * recall) / (precision + recall)
        except Exception as e:
            print(f"Error calculating f1: {e}")

        print(metric.summary())
        info = {
            "precision": precision,
            "recall": recall,
            "f1": f1,
            "miou": miou,
            "avg_time": np.mean(times),
            "min_time": np.min(times),
            "max_time": np.max(times),
        }
        return info

    def eval_text_recognition(
        self,
        images: Union[List[str], List[Image.Image]],
        target_results: list[list[OcrResult]],
    ):
        from doctr.utils import TextMatch

        metric = TextMatch()
        metric_perImage = TextMatch()
        index_raw_lraw_unicode_lunicode = []
        times = []
        for file_index, image in enumerate(images):
            if InferenceUtils.is_image(image):
                print("Processing file: ", file_index)
                file_name = file_index
            else:
                file_name = image
                print("Processing file: ", file_name)
                image = Image.open(file_name)
                file_name = file_name.split("/")[-1]
            ocrRes_target_page: [OcrResult] = target_results[file_index]
            detections_target_page = [ocrRes.detection for ocrRes in ocrRes_target_page]
            txt_target_page = [ocrRes.recognition.text for ocrRes in ocrRes_target_page]

            st = time.process_time()
            ocrRes_output_page = self.run_recognition(image, detections_target_page)
            et = time.process_time()
            txt_output_page = [ocrRes.recognition.text for ocrRes in ocrRes_output_page]
            try:
                metric.update(txt_target_page, txt_output_page)
                metric_perImage.update(txt_target_page, txt_output_page)
                raw, lraw, unicode, lunicode = metric_perImage.summary()
                index_raw_lraw_unicode_lunicode.append(
                    (file_name, raw, lraw, unicode, lunicode)
                )
                metric_perImage.reset()
            except Exception as e:
                print(e)
                print("Error in file: ", file_index)
            times.append(et - st)
        for index, raw, lraw, unic, lunic in index_raw_lraw_unicode_lunicode:
            print(
                "{:<8} {:<10} {:<10} {:<10} {:<10}".format(
                    index, raw, lraw, unic, lunic
                )
            )
        print(
            f"Average time: {np.mean(times)}"
            f" -- Min time: {np.min(times)}"
            f" -- Max time: {np.max(times)}"
        )

        print(metric.summary())
        recog_metrics = metric.summary()

        info = {
            **recog_metrics,
            "avg_time": np.mean(times),
            "min_time": np.min(times),
            "max_time": np.max(times),
        }
        return info

    def eval_e2e(
        self,
        images: Union[List[str], List[Image.Image]],
        target_results: [[OcrResult]],
        iou_thresh=0.5,
    ):
        from doctr.utils import OCRMetric

        metric = OCRMetric(iou_thresh=iou_thresh)
        times = []
        for file_index, image in enumerate(images):
            if InferenceUtils.is_image(image):
                print("Processing file: ", file_index)
            else:
                file_name = image
                print("Processing file: ", file_name)
                image = Image.open(file_name)
            ocrRes_target_page: list[OcrResult] = target_results[file_index]
            detections_target_page = [ocrRes.detection for ocrRes in ocrRes_target_page]
            xyxys_target = Detection.convert_detection_list_to_xyxy(
                detections_target_page,
                unormalize=True,
                width=image.size[0],
                height=image.size[1],
            )
            txt_target_page = [ocrRes.recognition.text for ocrRes in ocrRes_target_page]

            st = time.process_time()
            ocrRes_output_page = self.__call__(image)
            et = time.process_time()

            detections_out_page = [ocrRes.detection for ocrRes in ocrRes_output_page]
            txt_output_page = [ocrRes.recognition.text for ocrRes in ocrRes_output_page]
            xyxys_output = Detection.convert_detection_list_to_xyxy(
                detections_out_page,
                unormalize=True,
                width=image.size[0],
                height=image.size[1],
            )
            metric.update(
                np.asarray(xyxys_target),
                np.asarray(xyxys_output),
                txt_target_page,
                txt_output_page,
            )
            times.append(et - st)

        print(
            f"Average time: {np.mean(times)}"
            f" -- Min time: {np.min(times)}"
            f" -- Max time: {np.max(times)}"
        )
        print(metric.summary())
        return metric
