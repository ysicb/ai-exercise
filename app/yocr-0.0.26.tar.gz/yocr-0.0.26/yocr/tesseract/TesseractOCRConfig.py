from typing import Optional

from yocr.OCRConfig import OCRConfig


class TesseractOCRConfig(OCRConfig):
    tesseract_config: Optional[str] = "--psm 12"
    timeout: Optional[int] = 600
