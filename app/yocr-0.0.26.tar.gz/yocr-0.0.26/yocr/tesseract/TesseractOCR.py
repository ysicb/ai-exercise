from typing import List, Union, Tuple
from PIL import Image
import xmltodict

from yocr.OCRConfig import OCRConfig
from yocr.OCRBase import OCRBase
from yocr.data_struct.Detection import Detection
from yocr.data_struct.OcrResult import OcrResult
from yocr.data_struct.Recognition import Recognition
from yocr.data_struct.Orientation import Orientation
from yocr.tesseract.TesseractOCRConfig import TesseractOCRConfig
from yocr.utils.InferenceUtils import InferenceUtils


class TesseractOCR(OCRBase):
    def __init__(self, config: OCRConfig) -> None:
        super().__init__(config)
        self.engine_config = TesseractOCRConfig()

    def run(
        self, image: Union[str, Image.Image] = None, **kwargs
    ) -> List[OcrResult] or Tuple[List[OcrResult], List[OcrResult]]:
        import pytesseract

        # get image path or PIL image and return list of OcrResult
        if type(image) is str:
            image = Image.open(image)

        try:
            hocr_string = pytesseract.image_to_pdf_or_hocr(
                image,
                lang="eng",
                extension="hocr",
                config=self.engine_config.tesseract_config,
                timeout=kwargs.get("timeout", 120),
            )

        except Exception as e:
            err = "Tesseract Timeout " + str(e)
            raise Exception(err)

        ocr_dict = self.parse_and_verify(hocr_string)
        # by default, output_level="word" and returned List[OcrResult]
        output_level = kwargs.get("output_level", "word")
        if isinstance(output_level, list) and len(output_level) > 2:
            raise Exception("Tesseract supports 'line' or/and 'word' only!")

        if not ocr_dict:
            if isinstance(output_level, list) and len(output_level) == 2:
                return list(), list()
            else:
                return list()
        else:
            page = ocr_dict["html"]["body"]["div"]
            if isinstance(output_level, str):
                ocr_res = self.get_word_from_page(
                    page,
                    level=output_level,
                    wconf_threshold=kwargs.get("conf_thresh", 0),
                )
                formatted_ocr_res = self.convert_to_OcrResult(ocr_res, image)
            elif isinstance(output_level, list) and len(output_level) == 1:
                ocr_res = self.get_word_from_page(
                    page,
                    level=output_level[0],
                    wconf_threshold=kwargs.get("conf_thresh", 0),
                )
                formatted_ocr_res = self.convert_to_OcrResult(ocr_res, image)
            elif isinstance(output_level, list) and len(output_level) == 2:
                formatted_ocr_res = []
                for level in output_level:
                    ocr_res = self.get_word_from_page(
                        page,
                        level=level,
                        wconf_threshold=kwargs.get("conf_thresh", 0),
                    )
                    formatted_ocr_res.append(self.convert_to_OcrResult(ocr_res, image))
            else:
                raise Exception("Tesseract supports 'line' or/and 'word' only!")
            return formatted_ocr_res

    def convert_to_OcrResult(self, result, image) -> List[OcrResult]:
        ocrResults = []
        for e in result:
            bbox = e["bbox"][0]
            coordinates = [
                (bbox["left"] / image.width, bbox["top"] / image.height),
                (bbox["right"] / image.width, bbox["top"] / image.height),
                (bbox["right"] / image.width, bbox["bottom"] / image.height),
                (bbox["left"] / image.width, bbox["bottom"] / image.height),
            ]
            detection = Detection(coordinates=coordinates)

            if "wconf_avg" in e:
                conf_score = e["wconf_avg"] / 100
            elif "wconf" in e:
                conf_score = e["wconf"] / 100
            else:
                err_msg = "missing confidence score in hocr"
                raise Exception(err_msg)
            if "font_size" in e:
                font_sizes = [float(e["font_size"])]
            else:
                font_sizes = []
            recognition = Recognition(
                text=e["text"], conf_score=conf_score, font_sizes=font_sizes
            )
            if "angle" in e:
                ocrResults.append(
                    OcrResult(
                        detection=detection,
                        recognition=recognition,
                        direction=Orientation(angle=e["angle"]),
                    )
                )
            else:
                ocrResults.append(
                    OcrResult(detection=detection, recognition=recognition)
                )
        return ocrResults

    def parse_and_verify(self, hocr_string: str) -> dict:
        """
        @hocr_string raw output from tessseract
        @return dict representing hocr, or empty dict if parse and verify fail
        """
        if not hocr_string.strip():
            return dict()

        try:
            hocr_dict = xmltodict.parse(hocr_string)
        except Exception as e:
            err_msg = "error parsing hocr_string " + str(e)
            raise Exception(err_msg)

        if "html" not in hocr_dict or "body" not in hocr_dict["html"]:
            return dict()

        body = hocr_dict["html"]["body"]

        if "div" not in body:
            return dict()

        page = body["div"]
        if page["@class"] != "ocr_page":
            return dict()

        if "div" not in page:
            return dict()

        return hocr_dict

    def get_word_from_page(self, page, level="word", wconf_threshold=0):
        if level not in {"par", "line", "word", "area"}:
            raise Exception("invalid text grouping flag")

        res = list()

        areas = page["div"]
        if isinstance(
            areas, dict
        ):  # can be either dict (ocr_carea) or list of dict (ocr_carea)
            areas = [areas]

        for area in areas:
            paragraphs = area[
                "p"
            ]  # can be either dict (ocr_par) or list of dict (ocr_par)
            if isinstance(paragraphs, dict):
                paragraphs = [paragraphs]

            words_in_area = list()

            for paragraph in paragraphs:
                lines = paragraph["span"]
                if isinstance(lines, dict):
                    lines = [lines]
                words_in_par = list()
                for line in lines:
                    title = line["@title"]
                    font_size = self.get_font(title)
                    angle = self.get_text_angle(title)
                    words = line["span"]

                    if isinstance(words, dict):
                        words = [words]

                    words_in_line = list()
                    for word in words:
                        title = word["@title"]
                        wconf = self.get_word_conf(title)
                        bbox = self.get_bbox(title)
                        if "#text" not in word:
                            continue
                        text = word["#text"]
                        text = "".join(
                            [c if ord(c) < 128 else "" for c in text]
                        ).strip()
                        if wconf < wconf_threshold or not text.strip():
                            continue

                        word = {
                            "text": text,
                            "bbox": [bbox],
                            "font_size": font_size,
                            "angle": angle,
                            "wconf": wconf,
                        }

                        if level == "word":
                            res.append(word)
                        else:
                            words_in_line.append(word)

                    if not words_in_line:
                        continue

                    if level == "line":
                        text = " ".join(e["text"].strip() for e in words_in_line)
                        wconf_avg = sum(e["wconf"] for e in words_in_line) / len(
                            words_in_line
                        )
                        title = line["@title"]
                        bbox = [self.get_bbox(title)]
                        font_size = self.get_font(title)
                        angle = self.get_text_angle(title)
                        words_in_line_obj = {
                            "text": text,
                            "bbox": bbox,
                            "font_size": font_size,
                            "angle": angle,
                            "wconf_avg": wconf_avg,
                        }
                        res.append(words_in_line_obj)
                    elif level == "par":
                        words_in_par.extend(words_in_line)

                if not words_in_par:
                    continue

                if level == "par":
                    res.append(words_in_par)
                elif level == "area":
                    words_in_area.extend(words_in_par)

            if not words_in_area:
                continue

            if level == "area":
                res.append(words_in_area)

        return res

    def get_field_from_title(self, title: str, field_name: str) -> str:
        for field in title.split(";"):
            field = field.strip()
            if field.startswith(field_name + " "):
                return field
        return ""

    def get_bbox(self, title: str) -> dict:
        """
        @title the string in @title tag of tesseract object
        e.g. image "/tmp/tess_xed0vtnk.PNG"; bbox 0 0 1700 2200; ppageno 0
        @return the dict with these keys: "top", "bottom", "left", "right".
        The values are int.
        """

        bbox_text = self.get_field_from_title(title, "bbox")
        _, l, t, r, b = bbox_text.split()
        bbox_dict = {"top": int(t), "bottom": int(b), "left": int(l), "right": int(r)}
        return bbox_dict

    def get_word_conf(self, title: str) -> dict:
        wconf_text = self.get_field_from_title(title, "x_wconf")
        _, wconf = wconf_text.split()
        return int(wconf)

    def get_text_angle(self, title: str) -> float:
        angle_text = self.get_field_from_title(title, "textangle")
        if angle_text:
            _, angle = angle_text.split()
            return float(angle)
        else:
            return 0

    def get_font(self, title: str) -> float:
        font_text = self.get_field_from_title(title, "x_size")
        _, font_size = font_text.split()
        return float(font_size)

    def run_detection(
        self, image: Union[str, Image.Image], **kwargs
    ) -> List[Detection]:
        """
        It is hard to split text detection and recognition for tesseract.
        """
        ocrResults = self.run(image, **kwargs)
        detections = [ocrResult.detection for ocrResult in ocrResults]
        return detections

    def run_recognition(
        self, image: Union[str, Image.Image], detections: [Detection], **kwargs
    ) -> List[OcrResult]:
        if not InferenceUtils.is_image(image):
            image = Image.open(image)
        width = image.width
        height = image.height
        detection: Detection
        ocrResults: List[OcrResult] = []
        for detection in detections:
            # crop image for that particular detection
            xyxy = detection.get_coordinates_in_bbox()
            xyxy = Detection.unormalize_xyxy(xyxy, height, width)
            cropped_image = image.crop(xyxy)
            results: [OcrResult] = self.run(cropped_image, **kwargs)
            # merge all texts:
            text = " ".join([result.recognition.text for result in results])
            if len(results) == 0:
                confidence = 0.5
            else:
                confidence = sum(
                    [result.recognition.conf_score for result in results]
                ) / len(results)
            ocrResults.append(
                OcrResult(
                    detection=detection,
                    recognition=Recognition(text=text, conf_score=confidence),
                )
            )
        return ocrResults
