from typing import List, Optional

from pydantic import BaseModel


class Recognition(BaseModel):
    #: extracted text
    text: Optional[str] = ""
    #: confidence of the text prediction
    conf_score: Optional[float] = 0.0
    #: font size of the text
    font_sizes: Optional[List[float]] = []
    font_names: Optional[List[str]] = []

    def to_dict(self):
        return {
            "text": self.text,
            "conf_score": self.conf_score,
            "font_sizes": self.font_sizes,
            "font_names": self.font_names,
        }
