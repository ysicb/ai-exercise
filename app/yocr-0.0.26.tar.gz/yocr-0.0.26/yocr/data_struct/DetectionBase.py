from typing import List, Tuple

import numpy as np


class DetectionBase:
    @staticmethod
    def get_sorted_coords(coordinates):
        coords = np.array(coordinates)
        return sorted(
            [
                coords[:, 0].min(),
                coords[:, 0].max(),
                coords[:, 1].min(),
                coords[:, 1].max(),
            ]
        )

    def get_unormalize_coordinates(self, height, width):
        xpoints = [pt[0] * width for pt in self.coordinates]
        ypoints = [pt[1] * height for pt in self.coordinates]
        xmin = max(min(xpoints), 0)
        xmax = min(max(xpoints), width)
        ymin = max(min(ypoints), 0)
        ymax = min(max(ypoints), height)
        return [(xmin, ymin), (xmax, ymin), (xmax, ymax), (xmin, ymax)]

    def get_coordinates_in_xy_dict(self):
        return [{"x": point[0], "y": point[1]} for point in self.coordinates]

    def set_coordinates_from_xy(self, coordinates):
        self.coordinates = [(point["x"], point["y"]) for point in coordinates]
        return self

    def get_coordinates_in_bbox(self):
        return [
            self.coordinates[0][0],  # xmin
            self.coordinates[0][1],  # ymin
            self.coordinates[2][0],  # xmax
            self.coordinates[2][1],  # ymax
        ]

    def get_coordinates_in_bbox_unnormalized(self, height, width):
        return [
            self.coordinates[0][0] * width,  # xmin
            self.coordinates[0][1] * height,  # ymin
            self.coordinates[2][0] * width,  # xmax
            self.coordinates[2][1] * height,  # ymax
        ]

    def get_coordinates_in_xywh(self):
        return [
            self.coordinates[0][0],  # xmin
            self.coordinates[0][1],  # ymin
            self.coordinates[2][0] - self.coordinates[0][0],  # width
            self.coordinates[2][1] - self.coordinates[0][1],  # height
        ]

    def get_coordinates_in_xywh_unnormalized(self, height, width):
        return [
            int(self.coordinates[0][0] * width),  # xmin
            int(self.coordinates[0][1] * height),  # ymin
            int((self.coordinates[2][0] - self.coordinates[0][0]) * width),  # width
            int((self.coordinates[2][1] - self.coordinates[0][1]) * height),  # height
        ]

    def set_coordinates_from_bbox(self, bbox):
        self.coordinates = [
            (bbox[0], bbox[1]),  # xmin, ymin
            (bbox[2], bbox[1]),  # xmax, ymin
            (bbox[2], bbox[3]),  # xmax, ymax
            (bbox[0], bbox[3]),  # xmin, ymax
        ]
        return self

    @staticmethod
    def rotate_90_xyxy(xyxy):
        """
        xyxy: [xmin, ymin, xmax, ymax]
        """
        new_coordinates = [
            xyxy[1],  # ymin
            1 - xyxy[2],  # 1 - xmax
            xyxy[3],  # ymax
            1 - xyxy[0],  # 1 - xmin
        ]
        return new_coordinates

    @staticmethod
    def rotate_minus90_xyxy(xyxy):
        """
        xyxy: [xmin, ymin, xmax, ymax]
        """
        new_coordinates = [
            1 - xyxy[3],  # 1 - ymax
            xyxy[0],  # xmin
            1 - xyxy[1],  # 1 - ymin
            xyxy[2],  # xmax
        ]
        return new_coordinates

    @staticmethod
    def rotate_180_xyxy(xyxy):
        """
        xyxy: [xmin, ymin, xmax, ymax]
        """
        new_coordinates = [
            1 - xyxy[2],  # 1 - xmax
            1 - xyxy[3],  # 1 - ymax
            1 - xyxy[0],  # 1 - xmin
            1 - xyxy[1],  # 1 - ymin
        ]
        return new_coordinates

    def rotate_90_coordinates(self):
        """
        Rotate coordinates 90 degrees clockwise
        """
        new_coordinates = []
        for point in self.coordinates:
            new_coordinates.append(
                (
                    (1 - point[1]),
                    point[0],
                )
            )
        self.coordinates = new_coordinates
        return self

    def rotate_minus90_normalized_coordinates(self):
        """
        Rotate coordinates -90 degrees clockwise
        """
        new_coordinates = []
        for point in self.coordinates:
            new_coordinates.append(
                (
                    point[1],
                    1 - point[0],
                )
            )
        self.coordinates = new_coordinates
        return self

    def rotate_180_normalized_coordinates(self):
        """
        Rotate coordinates 180 degrees clockwise
        """
        new_coordinates = []
        for point in self.coordinates:
            new_coordinates.append(
                (
                    1 - point[0],
                    1 - point[1],
                )
            )
        self.coordinates = new_coordinates
        return self

    def set_coordinates_from_xywh(self, xywh):
        self.coordinates = [
            (xywh[0], xywh[1]),  # xmin, ymin
            (xywh[0] + xywh[2], xywh[1]),  # xmax, ymin
            (xywh[0] + xywh[2], xywh[1] + xywh[3]),  # xmax, ymax
            (xywh[0], xywh[1] + xywh[3]),  # xmin, ymax
        ]
        return self

    def set_coordinates_from_xywh_unnormalized(self, xywh, height, width):
        # convert xywh to float
        xywh = [float(x) for x in xywh]
        height = float(height)
        width = float(width)
        xmin = xywh[0] / width
        ymin = xywh[1] / height
        xmax = (xywh[0] + xywh[2]) / width
        ymax = (xywh[1] + xywh[3]) / height
        self.coordinates = [
            (xmin, ymin),  # xmin, ymin
            (xmax, ymin),  # xmax, ymin
            (xmax, ymax),  # xmax, ymax
            (xmin, ymax),  # xmin, ymax
        ]
        return self

    @staticmethod
    def get_distance(coordinates1, coordinates2):
        #:  coordinates [(xmin, ymin), (xmax, ymin), (xmax, ymax), (xmin, ymax)]
        center1 = (
            (coordinates1[0][0] + coordinates1[2][0]) / 2,
            (coordinates1[0][1] + coordinates1[2][1]) / 2,
        )
        center2 = (
            (coordinates2[0][0] + coordinates2[2][0]) / 2,
            (coordinates2[0][1] + coordinates2[2][1]) / 2,
        )
        return ((center1[0] - center2[0]) ** 2 + (center1[1] - center2[1]) ** 2) ** 0.5

    @staticmethod
    def convert_xyxy_to_coordinates(xyxy: [float]):
        return [
            (xyxy[0], xyxy[1]),
            (xyxy[2], xyxy[1]),
            (xyxy[2], xyxy[3]),
            (xyxy[0], xyxy[3]),
        ]

    def get_coordinates_in_geometry(
        self,
    ) -> Tuple[Tuple[float, float], Tuple[float, float]]:
        return (
            tuple(self.coordinates[0]),  # xmin, ymin
            tuple(self.coordinates[2]),  # xmax, ymax
        )

    def set_coordinates_from_geometry(
        self,
        geometry: Tuple[Tuple[float, float], Tuple[float, float]],
    ):
        self.coordinates = [
            geometry[0],  # xmin, ymin
            (geometry[1][0], geometry[0][1]),  # xmax, ymin
            geometry[1],  # xmax, ymax
            (geometry[0][0], geometry[1][1]),  # xmin, ymax
        ]
        return self

    @staticmethod
    def convert_geometry_to_coordinate(geometry):
        """
        geometry ((xmin, ymin), (xmax, ymax))
        """
        xmin, ymin = geometry[0]
        xmax, ymax = geometry[1]
        return [(xmin, ymin), (xmax, ymin), (xmax, ymax), (xmin, ymax)]

    @staticmethod
    def convert_polygon_to_xyxy(polygon_points):
        #
        # polygon_points: list of [x1 y1 x2 y2,...]
        #
        x1 = float(min(polygon_points[0::2]))
        y1 = float(min(polygon_points[1::2]))
        x2 = float(max(polygon_points[0::2]))
        y2 = float(max(polygon_points[1::2]))
        return [x1, y1, x2, y2]

    @staticmethod
    def convert_xywh_to_xyxy(bbox):
        #
        # bbox: [x1, y1, w, h]
        #
        return [
            int(bbox[0]),
            int(bbox[1]),
            int(bbox[0]) + int(bbox[2]),
            int(bbox[1]) + int(bbox[3]),
        ]

    @staticmethod
    def normalize_coords(coords, img_height, img_width):
        """
        coords [(xmin, ymin), (xmax, ymin), (xmax, ymax), (xmin, ymax)]
        """
        return [
            [
                float(coord[0]) / img_width,
                float(coord[1]) / img_height,
            ]
            for coord in coords
        ]

    @staticmethod
    def normalize_xyxy(bbox, img_height, img_width):
        #
        # bbox: [x1, y1, x2, y2]
        #
        return [
            float(bbox[0]) / img_width,
            float(bbox[1]) / img_height,
            float(bbox[2]) / img_width,
            float(bbox[3]) / img_height,
        ]

    @staticmethod
    def unormalize_xyxy(bbox, img_height, img_width):
        #
        # bbox: [x1, y1, x2, y2]
        #
        return [
            int(bbox[0] * img_width),
            int(bbox[1] * img_height),
            int(bbox[2] * img_width),
            int(bbox[3] * img_height),
        ]

    @staticmethod
    def convert_detection_list_to_xyxy(
        results: List["DetectionBase"],
        unormalize=False,
        width=None,
        height=None,
    ):
        xyxy_bbox_images = []
        result: DetectionBase
        for result in results:
            xyxy = result.get_coordinates_in_bbox()
            if unormalize:
                xyxy = DetectionBase.unormalize_xyxy(xyxy, height, width)
            xyxy_bbox_images.append(xyxy)

        return xyxy_bbox_images

    def get_size_of_box(self):
        return (self.coordinates[2][0] - self.coordinates[0][0]) * (
            self.coordinates[2][1] - self.coordinates[0][1]
        )

    @staticmethod
    def merge_if_overlap(detections: ["DetectionBase"]) -> ["DetectionBase"]:
        """
        detections.coordinates :
        [(xmin, ymin), (xmax, ymin), (xmax, ymax), (xmin, ymax)]
        """
        merged_detections = []
        for detection in detections:
            for merged_detection in merged_detections:
                if detection.is_overlap(merged_detection):
                    merged_detection.merge(detection)
                    break
            else:
                merged_detections.append(detection)

        return merged_detections

    def merge(self, detection: "DetectionBase"):
        """
        detection.coordinates :
        [(xmin, ymin), (xmax, ymin), (xmax, ymax), (xmin, ymax)]
        """
        xmin = min(self.coordinates[0][0], detection.coordinates[0][0])
        ymin = min(self.coordinates[0][1], detection.coordinates[0][1])
        xmax = max(self.coordinates[2][0], detection.coordinates[2][0])
        ymax = max(self.coordinates[2][1], detection.coordinates[2][1])
        self.coordinates = [(xmin, ymin), (xmax, ymin), (xmax, ymax), (xmin, ymax)]
        return self

    def is_overlap(self, detection: "DetectionBase", eps=0.005):
        """
        detection.coordinates :
        [(xmin, ymin), (xmax, ymin), (xmax, ymax), (xmin, ymax)]
        """
        # Get the coordinates of the first bounding box
        x1_min, y1_min = self.coordinates[0]
        x1_max, y1_max = self.coordinates[2]

        # Get the coordinates of the second bounding box
        x2_min, y2_min = detection.coordinates[0]
        x2_max, y2_max = detection.coordinates[2]

        x1_min -= eps
        x1_max += eps
        y1_min -= eps
        y1_max += eps
        x2_min -= eps
        x2_max += eps
        y2_min -= eps
        y2_max += eps
        # Check for overlap
        if x1_max <= x2_min or x1_min >= x2_max or y1_max <= y2_min or y1_min >= y2_max:
            return False
        else:
            return True

    def is_overlap_iou(self, detection: "DetectionBase", iou_threshold=0.5):
        if self.iou(detection) > iou_threshold:
            return True
        else:
            return False

    def iou(self, other):
        """
        :param other: DetectionBase
        :return: iou
        """
        # Get the coordinates of the first bounding box
        x1_min, y1_min = self.coordinates[0]
        x1_max, y1_max = self.coordinates[2]

        # Get the coordinates of the second bounding box
        x2_min, y2_min = other.coordinates[0]
        x2_max, y2_max = other.coordinates[2]

        # get the overlap rectangle
        overlap_x_min = max(x1_min, x2_min)
        overlap_y_min = max(y1_min, y2_min)
        overlap_x_max = min(x1_max, x2_max)
        overlap_y_max = min(y1_max, y2_max)

        # calculate area of overlap rectangle
        overlap_area = max(0, overlap_x_max - overlap_x_min) * max(
            0, overlap_y_max - overlap_y_min
        )

        # calculate area of each detection rectangle
        area_1 = (x1_max - x1_min) * (y1_max - y1_min)
        area_2 = (x2_max - x2_min) * (y2_max - y2_min)

        # calculate intersection over union
        iou = overlap_area / float(area_1 + area_2 - overlap_area)
        return iou

    @staticmethod
    def convert_relative_to_absolute_xyxy(xyxyInBlock, xyxyBlock):
        """
        xyxyInBlock: [x1, y1, x2, y2] inside block unormalized
        xyxyBlock: [x1, y1, x2, y2] block in image unormalized
        """
        x1 = xyxyInBlock[0] + xyxyBlock[0]
        y1 = xyxyInBlock[1] + xyxyBlock[1]
        x2 = xyxyInBlock[2] + xyxyBlock[0]
        y2 = xyxyInBlock[3] + xyxyBlock[1]
        return [x1, y1, x2, y2]

    @staticmethod
    def keep_if_overlap(
        ref_dets: ["DetectionBase"], dets: ["DetectionBase"]
    ) -> ["DetectionBase"]:
        kept_dets = []
        for det in dets:
            for ref_det in ref_dets:
                if det.is_overlap(ref_det):
                    kept_dets.append(ref_det)
                    break
        return kept_dets
