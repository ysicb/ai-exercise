from typing import Optional

from pydantic import BaseModel


class Orientation(BaseModel):
    #: angle of the word in the image
    angle: Optional[float] = 0.0
    #: confidence of the angle prediction
    conf_score: Optional[float] = 0.0

    def get_direction_in_str(self):
        if 88 < self.angle < 92:
            return "Vertical"
        else:
            return "Horizontal"

    def set_direction_from_str(self, orientation):
        if orientation == "Vertical":
            self.angle = 90
        else:
            self.angle = 0
        return self
