"""
General OCR class for all OCR methods
"""

import logging

from yocr.OCRBase import OCRBase
from yocr.OCRConfig import OCRConfig, OCRMethod
from yocr.trocr.DocTR_TROCR_inference import DocTR_TROCR

logger = logging.getLogger(__name__)


class OCR:
    """
    OCR main class

    Args:
        config (OCRConfig): config class for OCR
    Returns:
        OCRBase: OCR class
    Example:
        >>> from yocr.OCRConfig import OCRConfig, InferenceType
        >>> from yocr.OCR import OCR
        >>> from yocr.data_struct.OcrResult import OcrResult
        >>> config = OCRConfig(METHOD=OCRMethod.tesseract, CONFIG_PATH="config.json")
        >>> config.INFERENCE_TYPE = InferenceType.TILE
        >>> config.TILE_ROW_COUNT = 3
        >>> config.TILE_COL_COUNT = 3
        >>> config.TILE_OVERLAP = 300  # px
        >>> ocr = OCR(config)
        >>> results: [OcrResult] = ocr(image="image.png")

    Note:
        if you use `ocr.run`,
        it will apply ocr engine on the full image
        without applying any tiling or pre and postprocessing

    """

    def __new__(cls, config: OCRConfig) -> OCRBase:
        # print all attributes of the config class

        if config.METHOD is OCRMethod.doctr:
            from yocr.doctr.DoctrOCR import DoctrOCR

            return DoctrOCR(config)

        elif config.METHOD is OCRMethod.tesseract:
            from yocr.tesseract.TesseractOCR import TesseractOCR

            return TesseractOCR(config)

        elif config.METHOD is OCRMethod.doctr_dt_trocr_rec:
            return DocTR_TROCR(config)

        else:
            raise Exception("OCR method not supported")
