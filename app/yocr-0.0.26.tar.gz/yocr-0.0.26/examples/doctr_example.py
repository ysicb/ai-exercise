from yocr.OCR import OCR
from yocr.OCRConfig import OCRConfig, OCRMethod, InferenceType
from yocr.data_struct.OcrResult import OcrResult

image = "/home/antecessor/projects/Data/invoice2.png"

method = OCRMethod.doctr
inference_type = InferenceType.FULL
ocr_config = OCRConfig(METHOD=method, INFERENCE_TYPE=inference_type)
ocr = OCR(ocr_config)
results: [OcrResult] = ocr(image)
all_text = " ".join([result.recognition.text for result in results])
print(all_text)
