from yocr.OCR import OCR
from yocr.OCRConfig import OCRConfig, OCRMethod, InferenceType
from yocr.data_struct.OcrResult import OcrResult

image = "/home/antecessor/projects/Data/image_test.png"

method = OCRMethod.doctr_dt_trocr_rec
inference_type = InferenceType.FULL
ocr_config = OCRConfig(METHOD=method, INFERENCE_TYPE=inference_type)
ocr = OCR(ocr_config)
results: [OcrResult] = ocr(image)
all_text = " ".join([result.recognition.text for result in results])
print(all_text)
