from PIL import Image

from yocr.OCR import OCR
from yocr.OCRConfig import OCRConfig, OCRMethod, InferenceType
from yocr.data_struct.Block import Block
from yocr.data_struct.OcrResult import OcrResult
from yocr.utils.VisualizationUtils import VisualizationUtils

image = "/home/antecessor/projects/Data/image_test.png"
image_pil = Image.open(image)

method = OCRMethod.tesseract
inference_type = InferenceType.FULL
ocr_config = OCRConfig(METHOD=method, INFERENCE_TYPE=inference_type)
ocr = OCR(ocr_config)
results: [OcrResult] = ocr(image_pil)
width, height = image_pil.size
blocks: [Block] = ocr.get_hierarchy_of_info_from_lines(results, width, height)

image = VisualizationUtils.generate_block_line_word_bbox_overlay(image_pil, blocks)
image.save("result.png")
