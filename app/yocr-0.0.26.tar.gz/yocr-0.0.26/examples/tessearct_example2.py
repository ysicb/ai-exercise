from PIL import Image

from yocr.OCR import OCR
from yocr.OCRConfig import OCRConfig, OCRMethod, InferenceType
from yocr.data_struct.OcrResult import OcrResult

image = "/home/antecessor/projects/Data/image_test.png"
image_pil = Image.open(image)

method = OCRMethod.tesseract
inference_type = InferenceType.FULL
ocr_config = OCRConfig(METHOD=method, INFERENCE_TYPE=inference_type)
ocr = OCR(ocr_config)
results: [OcrResult] = ocr(image_pil)
width, height = image_pil.size
results_line = ocr.get_lines_from_word_level(results, width, height)

# Print information about each line
for i, line in enumerate(results_line, start=1):
    print(f"Line {i}:")
    print(f"  Text: {line.recognition.text}")
    print(f"  Coordinates: {line.detection.get_coordinates_in_bbox()}")
    print()

# Print information about each word in the entire image
for i, word in enumerate(results, start=1):
    print(f"Word {i}:")
    print(f"  Text: {word.recognition.text}")
    print(f"  Coordinates: {word.detection.get_coordinates_in_bbox()}")
    print()
