import requests
import json
from services.schemas import MainServiceConfig

# Replace the following variables with your actual values
base_url = "http://localhost:8001"  # Replace with your FastAPI server URL
endpoint = "/process"  # Replace with your actual endpoint
image_file_path = "/home/antecessor/projects/Data/image_test.png"  # Replace with the path to your image file

# Prepare the image file and configuration data
with open(image_file_path, "rb") as image_file:
    files = {"image": image_file}
    config = MainServiceConfig(ocr_engine="tesseract").dict()
    data = {"config": json.dumps(config)}

    # Send a POST request to the FastAPI endpoint using requests
    response = requests.post(base_url + endpoint, files=files, data=data)

    # Print the response from the server
    print(response.status_code)
    if response.status_code == 200:
        # Print the response content
        print("Response Content:")
        print(json.dumps(response.json(), indent=2))
